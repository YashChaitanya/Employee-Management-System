package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.customexception.IdNotFoundException;
import com.employee.customexception.SalaryNotValidException;
import com.employee.entity.Employee;
import com.employee.service.EmployeeService;

@RestController
public class EmployeeController  {
	@Autowired
	EmployeeService es;
	@PostMapping(path="/setData")
	public String setValue(@RequestBody List<Employee> e) {
		return es.setData(e);
	}
	@PostMapping(path="/setDat")
	public String setSalary(@RequestBody List<Employee>  x) throws SalaryNotValidException {
		return es.setSalary(x);
	}
	@GetMapping(path="/getById/{y}")
	public Employee getValueById(@PathVariable int y) throws IdNotFoundException {
		return es.getValueById(y);
	}

}
