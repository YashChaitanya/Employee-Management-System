package com.employee.customexception;

public class IdNotFoundException extends Exception {
	public  IdNotFoundException(String a) {
		super(a);
	}

}
