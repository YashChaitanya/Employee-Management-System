package com.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.customexception.IdNotFoundException;
import com.employee.customexception.SalaryNotValidException;
import com.employee.dao.EmployeeDao;
import com.employee.entity.Employee;

@Service
public class EmployeeService {
	@Autowired
	EmployeeDao ed;
	public String setData(List<Employee> m) {
		return ed.setData(m);
	}
	public String setSalary(List<Employee> y) throws SalaryNotValidException {
		List<Employee>ab=y.stream().filter(a->a.getSalary()<50000).toList();
		if(ab.isEmpty()) {
			return ed.setSalary(ab);
		}
		else {
			throw new SalaryNotValidException("NO Valid");
		}
	}
	public Employee getValueById(int y) throws IdNotFoundException {
		return ed.getValue(y);
	}

}
