package com.employee.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.employee.customexception.IdNotFoundException;
import com.employee.entity.Employee;
import com.employee.repository.EmployeeRepository;

@Repository
public class EmployeeDao {
@Autowired
EmployeeRepository er;
public String setData(List<Employee> m) {
	er.saveAll(m);
	return "runned succesfully";
}
public String setSalary(List<Employee> e) {
	er.saveAll(e);
	return "Success";
}
public Employee getValue(int y) throws IdNotFoundException{
	return er.findById(y).orElseThrow (()->new IdNotFoundException("Sorry this is not valid"));
}
}
