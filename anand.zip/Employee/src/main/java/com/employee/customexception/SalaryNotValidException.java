package com.employee.customexception;

public class SalaryNotValidException extends Exception {
	public  SalaryNotValidException(String a) {
		super(a);
	}
}
